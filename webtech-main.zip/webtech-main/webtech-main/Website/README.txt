This website is made by the Team Syntax

We used html5, css3, javascripts and more.

Credits:
	Icons:
		Font Awesome (fontawesome.io)

	Other:
		jQuery (jquery.com)
		Responsive Tools (github.com/ajlkn/responsive-tools)
